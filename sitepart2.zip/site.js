/* press-check portfolio — dynamic layer
   colour bar · reveals · entrance · parallax · crosshair cursor
   Every motion path respects prefers-reduced-motion and coarse pointers. */
(function () {
  "use strict";

  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var coarse = window.matchMedia("(hover: none), (pointer: coarse)").matches;
  var mobile = window.matchMedia("(max-width: 680px)");
  var doc = document.documentElement;

  /* ---------- colour bar reflects scroll progress ---------- */
  var fill = document.getElementById("cbfill");
  function progress() {
    var max = doc.scrollHeight - doc.clientHeight;
    var p = max > 0 ? (doc.scrollTop || window.pageYOffset) / max : 0;
    p = Math.max(0, Math.min(1, p));
    if (!fill) return;
    if (mobile.matches) { fill.style.width = (p * 100) + "%"; fill.style.height = ""; }
    else { fill.style.height = (p * 100) + "%"; fill.style.width = ""; }
  }

  /* ---------- image parallax on work rows ------------------ */
  var media = Array.prototype.slice.call(document.querySelectorAll(".wrow__media img"));
  function parallax() {
    if (reduce) return;
    var vh = window.innerHeight;
    for (var i = 0; i < media.length; i++) {
      var el = media[i];
      var r = el.getBoundingClientRect();
      if (r.bottom < 0 || r.top > vh) continue;
      var t = (r.top + r.height / 2 - vh / 2) / vh;
      el.style.setProperty("--py", (-6 + t * -7).toFixed(2) + "%");
    }
  }

  var ticking = false;
  function onScroll() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () { progress(); parallax(); ticking = false; });
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener("resize", function () { progress(); parallax(); });
  progress(); parallax();

  /* ---------- reveal on scroll ----------------------------- */
  var reveals = Array.prototype.slice.call(document.querySelectorAll(".reveal"));
  if (reduce || !("IntersectionObserver" in window)) {
    reveals.forEach(function (el) { el.classList.add("in"); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); }
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    reveals.forEach(function (el) { io.observe(el); });
  }

  /* ---------- entrance: masked line reveal ----------------- */
  document.body.classList.add("anim-ready");
  requestAnimationFrame(function () {
    requestAnimationFrame(function () { document.body.classList.add("anim-in"); });
  });

  /* ---------- custom crosshair cursor ---------------------- */
  if (!reduce && !coarse && window.matchMedia("(hover: hover)").matches) {
    var cur = document.createElement("div");
    cur.className = "cursor";
    cur.innerHTML = '<span class="cursor__ring"></span><span class="cursor__label">View ↗</span>';
    document.body.appendChild(cur);
    document.body.classList.add("has-cursor");

    var cx = window.innerWidth / 2, cy = window.innerHeight / 2, tx = cx, ty = cy, active = false;
    window.addEventListener("mousemove", function (e) {
      tx = e.clientX; ty = e.clientY;
      if (!active) { active = true; cur.classList.add("is-active"); }
    }, { passive: true });
    window.addEventListener("mouseleave", function () { active = false; cur.classList.remove("is-active"); });

    var viewers = Array.prototype.slice.call(document.querySelectorAll('[data-cursor="view"]'));
    viewers.forEach(function (el) {
      el.addEventListener("mouseenter", function () { cur.classList.add("is-view"); });
      el.addEventListener("mouseleave", function () { cur.classList.remove("is-view"); });
    });

    (function loop() {
      cx += (tx - cx) * 0.2; cy += (ty - cy) * 0.2;
      cur.style.left = cx + "px"; cur.style.top = cy + "px";
      requestAnimationFrame(loop);
    })();
  }
})();

/* ===== webproof: collapsible storefront browser ===== */
(function () {
  document.querySelectorAll('.webproof').forEach(function (wp) {
    var frame = wp.querySelector('.webproof__frame');
    var img = frame && frame.querySelector('img');
    var tabs = wp.querySelectorAll('.webproof__tab');
    if (!frame || !img || !tabs.length) return;

    function show(tab) {
      tabs.forEach(function (t) { t.setAttribute('aria-selected', t === tab ? 'true' : 'false'); });
      img.src = tab.getAttribute('data-src');
      img.alt = tab.getAttribute('data-alt') || '';
      frame.scrollTop = 0;
    }

    /* load nothing until first open */
    wp.addEventListener('toggle', function () {
      if (wp.open && !img.getAttribute('src')) show(tabs[0]);
    });

    tabs.forEach(function (t) {
      t.addEventListener('click', function () { show(t); });
    });

    /* arrow-key navigation across tabs */
    wp.querySelector('.webproof__bar').addEventListener('keydown', function (e) {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      var arr = Array.prototype.slice.call(tabs);
      var i = arr.findIndex(function (t) { return t.getAttribute('aria-selected') === 'true'; });
      var n = e.key === 'ArrowRight' ? (i + 1) % arr.length : (i - 1 + arr.length) % arr.length;
      arr[n].focus(); show(arr[n]);
    });
  });
})();

/* ===== lightbox: click any case-study image to expand ===== */
(function () {
  var sel = '.gallery__fig img, .strip__cell img, .secfig img, .case__cover, .photos img';
  if (!document.querySelector(sel)) return;
  var lb = document.createElement('div'); lb.className = 'lb';
  lb.innerHTML = '<button class="lb__x" aria-label="Close">Close &times;</button><img alt=""><div class="lb__cap"></div>';
  document.body.appendChild(lb);
  var img = lb.querySelector('img'), cap = lb.querySelector('.lb__cap');
  function close() { lb.classList.remove('on'); document.body.style.overflow = ''; }
  function open(src, alt, caption) {
    img.src = src; img.alt = alt || '';
    cap.textContent = caption || '';
    lb.classList.add('on'); document.body.style.overflow = 'hidden';
  }
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (lb.classList.contains('on')) {
      if (t === img) { close(); return; }
      if (t.closest('.lb')) { close(); return; }
    }
    if (!t.matches || !t.matches(sel)) return;
    var fig = t.closest('figure');
    var fc = fig && fig.querySelector('figcaption');
    open(t.currentSrc || t.src, t.alt, fc ? fc.textContent : '');
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && lb.classList.contains('on')) close();
  });
})();
